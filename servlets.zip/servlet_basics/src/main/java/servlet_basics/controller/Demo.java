package servlet_basics.controller;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

import servlet_basics.dao.PatientDao;
import servlet_basics.dto.PatientDto;

@WebServlet("/insert")
public class Demo implements Servlet{

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
//		System.out.println("hello servlet......");
//		res.getWriter().print(" <h1> hello servlet </h1> ");  //to get o/p in frontEnd 
		String id=req.getParameter("id"); //give same name in parameter which is given in frontend input-type name 
		String name=req.getParameter("name"); 
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		String telephone=req.getParameter("number");
		String gender=req.getParameter("gender");
		String checkbox=req.getParameter("checkbox");
		String country=req.getParameter("country");
//		System.out.println(id);
//		System.out.println(name);
//		System.out.println(email);
//		System.out.println(password);
//		System.out.println(telephone);
//		System.out.println(gender);
//		System.out.println(checkbox);
//		System.out.println(country);
//		
		
		int cid = Integer.parseInt(id); //to convert int type id from string type
		int cpwd =Integer.parseInt(password);
		 long cnum=Long.parseLong(telephone);
		PatientDto dto= new PatientDto();
		dto.setId(cid);
		dto.setName(name);
		dto.setEmail(email);
		dto.setPassword(cpwd);
		dto.setNumber(cnum);
		dto.setCountry(country);
		dto.setCheckbox(checkbox);
		dto.setGender(gender);
		
		System.out.println(dto);
		
		PatientDao dao= new PatientDao();
		dao.insert(dto);
		
	
		
	}

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

}

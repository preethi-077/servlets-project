package servlet_basics.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import servlet_basics.dto.PatientDto;

public class PatientDao {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("dev");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();
	
	public void insert(PatientDto d1) {
		entityTransaction.begin();
		entityManager.persist(d1);
		entityTransaction.commit();
		
	}
	
    public String deleteById(int id) {
    	PatientDto d1 = entityManager.find(PatientDto.class, id);
    	
    	if(d1 != null) {
    		entityTransaction.begin();
    		entityManager.remove(d1);
    		entityTransaction.commit();
    		return "data deleted";
    	} else
    		return "no data found";
    	}
    
    //to fetch all ..............
    public List<PatientDto> fetchAll() {
    	//select var_name from table_name(entity class) var_name (java persistence query language-JPQL)
    	Query q=entityManager.createQuery("select a from PatientDto a");
    	List<PatientDto> d1=q.getResultList();   //gives list of all objects
    	return d1;
    }
    
    
    
    public String update(int id, long number) {
    	PatientDto d1=entityManager.find(PatientDto.class , id);
    	d1.setNumber(number);
    	
    	entityTransaction.begin();
    	entityManager.merge(d1);
    	entityTransaction.commit();
    	
    	return "updated successfully";
    } 
    
    
    public void updateAll(PatientDto dto) {
    	entityTransaction.begin();
    	entityManager.merge(dto);
    	entityTransaction.commit();
    	
    	
    }
    
    
    
    }



























